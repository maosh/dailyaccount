﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dailyAccount
{
    class item
    {
        private int id;
        private string websitetype;
        private string website;
        private string loginname;
        private string card_owner;
        private string user;
        private string iplocation;
        private int  initmoney;
        private int ? avaimoney;
        private int ? deposit;
        private int ? rebate;
        private int ? tzmoney1;
        private double ? odds1;
        private int ? result1;
        private int ? tzmoney2;
        private double ? odds2;
        private int?  result2;

        private int ?  tzmoney3;
        private double ?  odds3;
        private int ? result3;
        private int ? tzmoney4;
        private double ? odds4;
        private int ? result4;

        private int ? tzmoney5;
        private double ? odds5;
        private int ? result5;
        private int ? tzmoney6;
        private double ? odds6;
        private int ? result6;

        private int ? tzmoney7;
        private double ? odds7;
        private int ? result7;
        private int ? tzmoney8;
        private double ? odds8;
        private int ? result8;

        private int ? tzmoney9;
        private double ? odds9;
        private int ? result9;
        private int ? tzmoney10;
        private double ? odds10;
        private int ? result10;

        private int ? tzmoney11;
        private double ? odds11;
        private int ? result11;

        private int ? withdraw1;
        private string wdresult1;
        private int ? withdraw2;
        private string wdresult2;
        private int ? nowmoney;

        public int Id
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Websitetype
        {
            get
            {
                return websitetype;
            }

            set
            {
                websitetype = value;
            }
        }

        public string Website
        {
            get
            {
                return website;
            }

            set
            {
                website = value;
            }
        }

        public string Loginname
        {
            get
            {
                return loginname;
            }

            set
            {
                loginname = value;
            }
        }


        public string Card_owner
        {
            get
            {
                return card_owner;
            }

            set
            {
                card_owner = value;
            }
        }

        public string User
        {
            get
            {
                return user;
            }

            set
            {
                user = value;
            }
        }

        public string Iplocation
        {
            get
            {
                return iplocation;
            }

            set
            {
                iplocation = value;
            }
        }

        public int  Initmoney
        {
            get
            {
                return initmoney;
            }

            set
            {
                initmoney = value;
            }
        }

        public int ? Avaimoney
        {
            get
            {
                return avaimoney;
            }

            set
            {
                avaimoney = value;
            }
        }

        public int ? Deposit
        {
            get
            {
                return deposit;
            }

            set
            {
                deposit = value;
            }
        }

        public int ? Rebate
        {
            get
            {
                return rebate;
            }

            set
            {
                rebate = value;
            }
        }

        public int ? Tzmoney1
        {
            get
            {
                return tzmoney1;
            }

            set
            {
                tzmoney1 = value;
            }
        }

        public double ? Odds1
        {
            get
            {
                return odds1;
            }

            set
            {
                odds1 = value;
            }
        }

        public int ? Result1
        {
            get
            {
                return result1;
            }

            set
            {
                result1 = value;
            }
        }

        public int ? Tzmoney2
        {
            get
            {
                return tzmoney2;
            }

            set
            {
                tzmoney2 = value;
            }
        }

        public double ? Odds2
        {
            get
            {
                return odds2;
            }

            set
            {
                odds2 = value;
            }
        }

        public int ? Result2
        {
            get
            {
                return result2;
            }

            set
            {
                result2 = value;
            }
        }

        public int ? Tzmoney3
        {
            get
            {
                return tzmoney3;
            }

            set
            {
                tzmoney3 = value;
            }
        }

        public double ? Odds3
        {
            get
            {
                return odds3;
            }

            set
            {
                odds3 = value;
            }
        }

        public int ? Result3
        {
            get
            {
                return result3;
            }

            set
            {
                result3 = value;
            }
        }

        public int ? Tzmoney4
        {
            get
            {
                return tzmoney4;
            }

            set
            {
                tzmoney4 = value;
            }
        }

        public double ? Odds4
        {
            get
            {
                return odds4;
            }

            set
            {
                odds4 = value;
            }
        }

        public int ? Result4
        {
            get
            {
                return result4;
            }

            set
            {
                result4 = value;
            }
        }

        public int ? Tzmoney5
        {
            get
            {
                return tzmoney5;
            }

            set
            {
                tzmoney5 = value;
            }
        }

        public double ? Odds5
        {
            get
            {
                return odds5;
            }

            set
            {
                odds5 = value;
            }
        }

        public int ? Result5
        {
            get
            {
                return result5;
            }

            set
            {
                result5 = value;
            }
        }

        public int ? Tzmoney6
        {
            get
            {
                return tzmoney6;
            }

            set
            {
                tzmoney6 = value;
            }
        }

        public double ? Odds6
        {
            get
            {
                return odds6;
            }

            set
            {
                odds6 = value;
            }
        }

        public int ? Result6
        {
            get
            {
                return result6;
            }

            set
            {
                result6 = value;
            }
        }

        public int ? Tzmoney7
        {
            get
            {
                return tzmoney7;
            }

            set
            {
                tzmoney7 = value;
            }
        }

        public double ? Odds7
        {
            get
            {
                return odds7;
            }

            set
            {
                odds7 = value;
            }
        }

        public int ? Result7
        {
            get
            {
                return result7;
            }

            set
            {
                result7 = value;
            }
        }

        public int ? Tzmoney8
        {
            get
            {
                return tzmoney8;
            }

            set
            {
                tzmoney8 = value;
            }
        }

        public double ? Odds8
        {
            get
            {
                return odds8;
            }

            set
            {
                odds8 = value;
            }
        }

        public int ? Result8
        {
            get
            {
                return result8;
            }

            set
            {
                result8 = value;
            }
        }

        public int ? Tzmoney9
        {
            get
            {
                return tzmoney9;
            }

            set
            {
                tzmoney9 = value;
            }
        }

        public double ? Odds9
        {
            get
            {
                return odds9;
            }

            set
            {
                odds9 = value;
            }
        }

        public int ? Result9
        {
            get
            {
                return result9;
            }

            set
            {
                result9 = value;
            }
        }

        public int ? Tzmoney10
        {
            get
            {
                return tzmoney10;
            }

            set
            {
                tzmoney10 = value;
            }
        }

        public double ? Odds10
        {
            get
            {
                return odds10;
            }

            set
            {
                odds10 = value;
            }
        }

        public int ? Result10
        {
            get
            {
                return result10;
            }

            set
            {
                result10 = value;
            }
        }

        public int ? Tzmoney11
        {
            get
            {
                return tzmoney11;
            }

            set
            {
                tzmoney11 = value;
            }
        }

        public double ? Odds11
        {
            get
            {
                return odds11;
            }

            set
            {
                odds11 = value;
            }
        }

        public int ? Result11
        {
            get
            {
                return result11;
            }

            set
            {
                result11 = value;
            }
        }

        public int ? Withdraw1
        {
            get
            {
                return withdraw1;
            }

            set
            {
                withdraw1 = value;
            }
        }

        public string Wdresult1
        {
            get
            {
                return wdresult1;
            }

            set
            {
                wdresult1 = value;
            }
        }

        public int ? Withdraw2
        {
            get
            {
                return withdraw2;
            }

            set
            {
                withdraw2 = value;
            }
        }

        public string Wdresult2
        {
            get
            {
                return wdresult2;
            }

            set
            {
                wdresult2 = value;
            }
        }

        public int ? Nowmoney
        {
            get
            {
                return nowmoney;
            }

            set
            {
                nowmoney = value;
            }
        }
    }
}
